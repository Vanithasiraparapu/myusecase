var express=require('express');
var router=express.Router();
var mongoClient=require('mongodb').MongoClient;
var ObjectID= require('mongodb').ObjectID;
const fs = require('fs');
const connection = (closure) => {
    return mongoClient.connect('mongodb://miracle:miracle16@ds121321.mlab.com:21321/blockchain', (err,client) => {
        if(err)
        {
            console.log(err);
        }
        var db=client.db('blockchain');
        console.log('successfully connected to the database');
        closure(db);
    })
}


let response = {
    status: 200,
    data: [],
}

var sendError = (err, res) => {
    response.status  = 501;
    response.message = typeof err == "object" ? err.message: err;
    response.status(501).json(response);
}

router.post('/login',(req,res) => {
    connection((db) => {
        db.collection('login').find({$and: [{username:req.body.uname}, {password:req.body.pwd}]}).toArray().then((login) => {
            // response.data=login;
            console.log(login);
            res.json(login);
           
        })
    })
})
router.post('/performTransaction',(req,res) => {
    console.log(JSON.parse(req).url);
    console.log(JSON.parse(req).formData);
})
router.post('/getTransactionFields',(req,res) => {
    console.log('entered getTransactionFields request '+req.body.transactionName);
    fs.readFile('FieldData.json', (err, data) => {  
        if (err) throw err;
        var fieldData;
        if(req.body.transactionName == "setUpDemo")
            fieldData=JSON.parse(data).setUpDemo;
        else if(req.body.transactionName == "createProduct")
            fieldData=data.createProduct;
        else if(req.body.transactionName == "orderProduct")
            fieldData=data.orderProduct;
        else if(req.body.transactionName == "claimWarranty")
            fieldData=data.claimWarranty;
          var json={
              "success":"success",
              "data":fieldData
          }
          console.log(JSON.stringify(json));
        res.json(json);
    });
})

module.exports = router;