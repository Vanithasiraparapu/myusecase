var express = require('express');
var bodyParser= require('body-parser');
var path= require('path');
var http= require('http');
var cors=require('cors');
var app=express();
var api=require('./server/api.js');
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(path.join(__dirname,'dist/BlockChainUI')));
app.use('/',api);
app.post('*'), (req,res)=>{
    console.log('entered post equest for dist/index');
    res.sendFile(path.join(__dirname,'dist/index.html'));
}
var port= process.env.PORT || '3000';
app.set('port',port);
app.listen(port,
    ()=>console.log("server is running on port 3000"));
//var server = http.createServer(app);
//server.listen(port,()=>console.log("server is running"));