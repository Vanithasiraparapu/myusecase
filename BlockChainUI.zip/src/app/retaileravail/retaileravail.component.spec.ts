import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetaileravailComponent } from './retaileravail.component';

describe('RetaileravailComponent', () => {
  let component: RetaileravailComponent;
  let fixture: ComponentFixture<RetaileravailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetaileravailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetaileravailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
