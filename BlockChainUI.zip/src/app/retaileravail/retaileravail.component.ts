import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';
@Component({
  selector: 'app-retaileravail',
  templateUrl: './retaileravail.component.html',
  styleUrls: ['./retaileravail.component.css']
})
export class RetaileravailComponent implements OnInit {
  availableQty : any =[];
  responseData:any=[];
  displayData:any=[];
  soldData:any=[];
  rOrderqty:any=[];
  cOrderqty:any=[];
  constructor(private dataService:AppService) { }

  ngOnInit() {
    this.dataService.getRetailer().subscribe(response=>{
      this.responseData=response;
      // console.log('retailer',this.responseData);
      for(let  i=0;i<this.responseData.length;i++){
        if(this.responseData[i].soldProductDetails.length==0){
         this.soldData[i]={}; 
        }
        else{
           for(let j=0; j<this.responseData[i].soldProductDetails.length;j++)
           {
            this.soldData.push(JSON.parse(this.responseData[i].soldProductDetails[j]));
            // console.log('data',this.soldData);
           }
           
        }
       }
    })
  }

}
