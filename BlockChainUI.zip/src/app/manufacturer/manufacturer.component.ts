import { Subject } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { SidemenuRoutesService } from '../sidemenu-routes.service';
import { PlatformLocation } from '@angular/common';

@Component({
  selector: 'app-manufacturer',
  templateUrl: './manufacturer.component.html',
  styleUrls: ['./manufacturer.component.css']
})
export class ManufacturerComponent implements OnInit {

  constructor(public sidemenu:SidemenuRoutesService) { 
    var routes = [
      {
        'name':'Manufacturers','route':'/dashboard/manufacturer/details'
      }
      // {
      //   'name':'Add New Product','route':'/dashboard/manufacturer/createProduct'
      // },
      // {
      //   'name':'Manufacturer Inventory','route':'/dashboard/manufacturer/manufacturerdata'
      // },
      // {
      //   'name':'View Available Products','route':'/dashboard/manufacturer/availProducts'
      // },
      // {
      //   'name':'View Sold Products','route':'/dashboard/manufacturer/soldProducts'
      // }]
    ]
    this.sidemenu.sideRoutes(routes);
  
  }
  ngOnInit() {
  }

}
