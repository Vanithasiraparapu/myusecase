import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
var url='http://192.168.1.196:3000/api/com.miraclesoft.blockchain.';
@Injectable({
  providedIn: 'root'
})
export class AppService {
result:any=[];
  constructor(private _http:Http) { }
  getProduct()
  {
    // console.log('inside service');
  return this._http.get(url+'Product')
    
    .map(result =>
          this.result = result.json());
          // console.log(result))
  }
  createProduct(data)
  {
    return this._http.post(url+'createProduct',data)
    .map(result => 
        this.result=result.json());
  }
  getManufacturer()
  {
    return this._http.get(url+'Manufacturer' )
    .map(result => 
        this.result=result.json());
  }
  addManufacturer(data)
  {
    // console.log('inside add manufacturer');
    return this._http.post(url+'Manufacturer',data)
    .map(result => 
        this.result=result.json());
  }
  getRetailer()
  {
    // console.log('get Retailer');
    return this._http.get(url+'Retailer' )
    .map(result => 
        this.result=result.json());
  }
  addRetailer(data)
  {
    // console.log('inside add manufacturer');
    return this._http.post(url+'Retailer',data)
    .map(result => 
        this.result=result.json());
  }
  getOrderHistory()
  {
    // console.log('service');
    return this._http.get(url+'Order' )
    .map(result => 
        this.result=result.json());
  }
  getCustomer()
  {
    
    return this._http.get(url+'Customer' )
    .map(result => 
        this.result=result.json());
  }
  addCustomer(data)
  {
    // console.log('inside add manufacturer');
    return this._http.post(url+'Customer ',data)
    .map(result => 
        this.result=result.json());
  }
  placeRetailerOrder(data)
  {
    // console.log('inside place retailer order');
    return this._http.post(url+'orderProduct  ',data)
    .map(result => 
        this.result=result.json());
        // console.log(result.json()));
  }
  placeCustomerOrder(data)
  {
    // console.log('inside place customer order');
    return this._http.post(url+'orderProductFromRetailer',data)
    .map(result => 
        // this.result=result.json());
        console.log(result.json()));
  }
}
