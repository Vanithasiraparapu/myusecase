import { Component, OnInit } from '@angular/core';
import { SidemenuRoutesService } from '../sidemenu-routes.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(public sidemenu:SidemenuRoutesService) {
    var routes = [{
      'name':'Customers','route':'/dashboard/customer/customerDetails',   
    },
    // {
    //   'name':'Customers Data','route':'/dashboard/customer/customerData',
      
    // },
    {
      'name':'Order Product','route':'/dashboard/customer/placeOrder',
      
    },
    {
      'name':'Order History','route':'/dashboard/customer/orderHistory',
      
    }]
    this.sidemenu.sideRoutes(routes)
   }

  ngOnInit() {
  }

}
