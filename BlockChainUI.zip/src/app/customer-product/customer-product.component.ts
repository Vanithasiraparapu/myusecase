import { Component, OnInit, Inject } from '@angular/core';
import { AppService } from '../services/app.service';
import {NgbModal, ModalDismissReasons, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { UUID } from 'angular2-uuid';
@Component({
  selector: 'app-customer-product',
  templateUrl: './customer-product.component.html',
  styleUrls: ['./customer-product.component.css']
})
export class CustomerProductComponent implements OnInit {
  error:any;
  displayDate=new Date();
  data:any=[];
  soldData:any=[];
  doneData:any=[]
  // displayData:any=[];
  form:FormGroup;
  orderData:any={};
  availData:any=[];
  private modalRef: NgbModalRef;
  uuid = UUID.UUID();
  constructor(private placeOrderService:AppService,
              private modalService: NgbModal,
              private _formbuilder:FormBuilder,
              private dialog: MatDialog) {
    this.form=this._formbuilder.group({
      // rid:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
      cname:['',[Validators.required,Validators.required,Validators.email]],
      type:['',Validators.required],
      model:['',Validators.required],
      owner:['',[Validators.required,Validators.email]],
      qty:['',Validators.required]
    })
   }

    ngOnInit() {
     
      // console.log('uuid',this.uuid.substring(0,4));
      this.placeOrderService.getRetailer().subscribe(response=>{
        this.data=response;
        // console.log('retailer',this.data);
        for(let  i=0;i<this.data.length;i++){
            // console.log(this.data[i].email);
            if(this.data[i].availableProduct.length==0){
              this.availData=[];
              // console.log('inside if')
             }
             else{
              //  console.log('inside else');
                for(let j=0; j<this.data[i].availableProduct.length;j++)
                {
                //  console.log(JSON.parse(this.data[i].availableProduct[j]))
                this.availData.push(JSON.parse(this.data[i].availableProduct[j]));
                }
                
             }
         }
      })
  }
  open(content){
    this.modalRef= this.modalService.open(content, { size: 'lg' });
  }
  addNewOrder()
  {
    this.modalRef.close();
    // var val = Math.floor(1000 + Math.random() * 9000);
    // console.log(val);
    // var val=this.uuid.substring(0,4);
    this.orderData={
      "$class": "com.miraclesoft.blockchain.orderProductFromRetailer",
      "order": {
        "$class": "com.miraclesoft.blockchain.Order",
        "orderId": this.uuid,
        "orderDate": this.displayDate,
        "orderPerson": this.form.value.cname,
        "ordererType": "CUSTOMER",
        "orderStatus": "CREATED",
        "orderProviderName": this.form.value.owner,
        "productQualities": {
          "$class": "com.miraclesoft.blockchain.ProductQualities",
          "productType": this.form.value.type,
          "productModel": this.form.value.model,
          "productConfiguration": "string"
        },
        "orderQuantity": this.form.value.qty,
        "saleItemSerial": []
      },
      "timestamp": this.displayDate
    }
      // console.log('---------',this.orderData);
      this.placeOrderService.placeCustomerOrder(this.orderData).subscribe(response=>{
        this.doneData=response;
        console.log(response);
        let dialogRef = this.dialog.open(DialogExample, {
          width: 'sm',
          data: {'modalDate':this.doneData.order.orderDate,'TransactionId':this.doneData.transactionId,'message':'Order Placed Successfully '}
        });
    
        dialogRef.afterClosed().subscribe(result => {
          // console.log('The dialog was closed');
        });
        this.form.reset();
      },error=>{
        let msg=JSON.parse(error._body).error;
        if(msg){
          this.error='Error in placing the order';
          let dialogRef = this.dialog.open(DialogExample, {
            width: 'sm',
            data: {'message':this.error}
          });
      
          dialogRef.afterClosed().subscribe(result => {
            // console.log('The dialog was closed');
          });
        }
        this.form.reset()
      })
      this.form.reset()
  }

}


@Component({
  selector: 'dialog-example',
  templateUrl: 'dialog-example.html',
})
export class DialogExample {
  
  constructor(
    private dialogRef: MatDialogRef<DialogExample>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 

     
    }


  close()
  {
    this.dialogRef.close();
  }

}