import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { COrderDetailsComponent } from './c-order-details.component';

describe('COrderDetailsComponent', () => {
  let component: COrderDetailsComponent;
  let fixture: ComponentFixture<COrderDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ COrderDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(COrderDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
