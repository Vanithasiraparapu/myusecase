import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-c-order-details',
  templateUrl: './c-order-details.component.html',
  styleUrls: ['./c-order-details.component.css']
})
export class COrderDetailsComponent implements OnInit {
 orderHistory:any=[];
 date:any=[];
  constructor(private orderService:AppService) { }

  ngOnInit() {
    this.orderService.getOrderHistory().subscribe(response=>{
      // console.log(response)
      for(let i=0;i<response.length;i++){
        if(response[i].ordererType=="CUSTOMER")
        {
          console.log(response[i]);
          this.orderHistory.push(response[i]);
        }
      }
      for(let i=0;i<this.orderHistory.length;i++){
        console.log(this.orderHistory[i].orderDate);
        this.date.push((this.orderHistory[i].orderDate).split("T",2));
        console.log(this.date);
      }
    })
  }

}
