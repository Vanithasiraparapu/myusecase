import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-sold-products',
  templateUrl: './sold-products.component.html',
  styleUrls: ['./sold-products.component.css']
})
export class SoldProductsComponent implements OnInit {
  data:any=[];
  soldData:any=[];
  displayData:any=[];
  constructor(private soldProductsService:AppService) { }

    ngOnInit() {
      this.soldProductsService.getProduct().subscribe(response=>{
        this.data=response;
        // for(let  i=0;i<this.data.length;i++){
        // if(this.data[i].soldProductDetails.length==0){

        //   this.soldData[i]={}; 
        // }
        // else{
        //     this.soldData[i]=this.data[i].soldProductDetails;
        // }
        // }
        for(let  i=0;i<this.data.length;i++){
          if(this.data[i].soldProductDetails.length==0){
   
           this.displayData[i]={}; 
          }
          else{
             this.soldData[i]=this.data[i].soldProductDetails;
            // console.log('11111111111',this.soldData[i]);
             for(let j=0; j< this.soldData[i].length;j++){
               console.log(JSON.parse(this.soldData[i][j]));
               this.displayData.push(JSON.parse(this.soldData[i][j]));
             }
          }
         }
    })
  }
}
