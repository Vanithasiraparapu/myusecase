import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CustomerComponent } from './customer/customer.component';
import { ManufacturerComponent } from './manufacturer/manufacturer.component';
import { LoginComponent } from './login/login.component';
import { CreateproductComponent } from './createproduct/createproduct.component';
import { DataComponent } from './data/data.component';
import { RetailerComponent } from './retailer/retailer.component';
import { MandetailsComponent } from './mandetails/mandetails.component';
import { AvailProductsComponent } from './avail-products/avail-products.component';
import { SoldProductsComponent } from './sold-products/sold-products.component';
import { RetailerdetailsComponent } from './retailerdetails/retailerdetails.component';
import { RetailerdataComponent } from './retailerdata/retailerdata.component';
import { RetaileravailComponent } from './retaileravail/retaileravail.component';
import { RetailersoldComponent } from './retailersold/retailersold.component';
import { CustomerdetailsComponent } from './customerdetails/customerdetails.component';
import { CustomerdataComponent } from './customerdata/customerdata.component';
import { RetailerProductComponent } from './retailer-product/retailer-product.component';
import { CustomerProductComponent } from './customer-product/customer-product.component';
import { COrderDetailsComponent } from './c-order-details/c-order-details.component';
import { ROrderDetailsComponent } from './r-order-details/r-order-details.component';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path:'login',component:LoginComponent
  },
  {
    path:'dashboard' ,component: DashboardComponent,
    children:[
                  
              {
                path:'customer',component:CustomerComponent,
                children:[
                  {
                    path:'customerDetails',component:CustomerdetailsComponent
                  },
                  {
                    path:'customerData',component:CustomerdataComponent
                  },
                  {
                    path:'placeOrder',component:CustomerProductComponent
                  },
                {
                   path:'orderHistory',component:COrderDetailsComponent
                }]
              },
              {
                path:'manufacturer',component:ManufacturerComponent,
                children:[
                  {
                    path:'details',component:MandetailsComponent
                  },
                  {
                    path:'createProduct',component:CreateproductComponent
                  },
                  {
                    path:'manufacturerdata',component:DataComponent
                  },
                  {
                    path:'availProducts',component:AvailProductsComponent
                  },
                  {
                    path:'soldProducts',component:SoldProductsComponent
                  }
                  
                ]
              },
              {
                path:'retailer',component:RetailerComponent,
                children:[
                 
                  {
                    path:'retailersDetails',component:RetailerdetailsComponent
                  },
                  {
                    path:'retailerdata',component:RetailerdataComponent
                  },
                  {
                    path:'availProducts',component:RetaileravailComponent
                  },
                  {
                    path:'soldProducts',component:RetailersoldComponent
                  },
                  {
                    path:'createProduct',component:RetailerProductComponent
                  },
                  {
                    path:'orderHistory',component:ROrderDetailsComponent
                  },
                ]
              }
            ]
  }  
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule {
}