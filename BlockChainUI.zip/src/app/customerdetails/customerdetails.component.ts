import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppService } from '../services/app.service';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {NgbModal, ModalDismissReasons, NgbActiveModal,NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-customerdetails',
  templateUrl: './customerdetails.component.html',
  styleUrls: ['./customerdetails.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class CustomerdetailsComponent implements OnInit {
  customerData:any=[];
  responseData:any=[];
  availData:any=[]
  private modalRef: NgbModalRef;
  closeResult: string;
  data:any={};
  form:FormGroup;
  cardData:boolean=false;
  index:any;
  customer:any;
  constructor(private detailsService:AppService,
              private modalService: NgbModal,
              private _formbuilder:FormBuilder) { 

                this.form=this._formbuilder.group({
                  id:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
                  name:['',Validators.required],
                  email:['',[Validators.required,Validators.email]],
                  city:['',Validators.required],
                  state:['',Validators.required],
                  country:['',Validators.required],
                  pcode:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
                  blc:['',[Validators.required,Validators.pattern('^[0-9]+$')]]
                })

  }

  ngOnInit() {

    this.detailsService.getCustomer().subscribe(response=>{
      this.customerData=response;
      // console.log(this.customerData);
  })
  }
  showCard(index)
  {
    this.cardData=!this.cardData;
    this.index=index;
  }
  openAvail(availContent,email){
    this.modalRef= this.modalService.open(availContent,{ size: 'lg' });
    this.customer=email;
    this.detailsService.getCustomer().subscribe(response=>{
     this.responseData=response;
    //  console.log(this.responseData);
    this.availData=[];
     for(let  i=0;i<this.responseData.length;i++){
      //  console.log(this.customer,this.responseData[i].email);
      if(this.responseData[i].email==this.customer){
        // console.log(this.responseData[i].email);
        if(this.responseData[i].availableProduct.length!=0){
          for(let j=0; j<this.responseData[i].availableProduct.length;j++)
            {
            //  console.log(JSON.parse(this.responseData[i].availableProduct[j]))
            this.availData.push(JSON.parse(this.responseData[i].availableProduct[j]));
            console.log(this.availData);
            }
          
         }
            
        }
     }
    })
  }

  open(content) {
    this.modalRef= this.modalService.open(content,{ size: 'lg' });
  }
  addNewCustomer(){
    console.log('-------------------',this.form.value)
    this.modalRef.close();
    this.data= {
        "$class": "com.miraclesoft.blockchain.Customer",
        "customerid": this.form.value.id,
        "name": this.form.value.name,
        "email": this.form.value.email,
        "address": {
            "$class": "com.miraclesoft.blockchain.Address",
            "city": this.form.value.city,
            "state": this.form.value.state,
            "country": this.form.value.country,
            "pincode": this.form.value.pcode
        },
        "balance": this.form.value.blc,
        "availableProduct": [],
        "soldProductDetails": [],
        "availableProductSerialNo": []
  }
    this.detailsService.addCustomer(this.data).subscribe(response=>{
      this.ngOnInit();
    })
    this.form.reset()
  }

}
