import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { AppService } from '../services/app.service';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {NgbModal, ModalDismissReasons, NgbActiveModal,NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import {MatSnackBar,MatSnackBarConfig} from '@angular/material';
import { UUID } from 'angular2-uuid';

@Component({
  selector: 'app-mandetails',
  templateUrl: './mandetails.component.html',
  styleUrls: ['./mandetails.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MandetailsComponent implements OnInit {
uuid = UUID.UUID();
index:any;
cardData:boolean=false;
manufacturerData:any=[];
data:any={}
private modalRef: NgbModalRef;
form:FormGroup;
closeResult: string;
displayDate=new Date();
createForm:FormGroup;
loader:boolean=false
createData:any={};
doneData:any={};
error:any;
manufacturer:any;
availData:any=[];
soldData:any=[];
displayData:any=[];
displaySoldData:any=[]
text:any;
tableData:any=[]
  constructor(private detailsService:AppService,
              private modalService: NgbModal,
              private _formbuilder:FormBuilder,
              private router:Router,
              public snackBar: MatSnackBar) { 
    this.form=this._formbuilder.group({
              cid:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
              cname:['',Validators.required],
              cemail:['',[Validators.required,Validators.email]],
              city:['',Validators.required],
              state:['',Validators.required],
              country:['',Validators.required],
              pcode:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
              blc:['',[Validators.required,Validators.pattern('^[0-9]+$')]]
            });
    this.createForm=this._formbuilder.group({
              ptype:['',Validators.required],
              pmodel:['',Validators.required],
              // pid:['',Validators.required],
              // man:['',[Validators.required,Validators.email]],
              warranty:['',[Validators.required,Validators.pattern('^[0-9]$')]],
              quantity:['',[Validators.required,Validators.pattern('^[0-9]+$')]]
            })
  }

  ngOnInit() {
    this.detailsService.getManufacturer().subscribe(response=>{
      this.manufacturerData=response;
      // console.log(this.manufacturerData);
  })



  }

  open(content) {
    this.modalRef= this.modalService.open(content,{ size: 'lg' });
  }
  addNewManufacturer(){
    // console.log('-------------------')
    this.modalRef.close();
    this.data={
      "$class": "com.miraclesoft.blockchain.Manufacturer",
      "companyid": this.form.value.cid,
      "name": this.form.value.cname,
      "email": this.form.value.cemail,
      "address": {
          "$class": "com.miraclesoft.blockchain.Address",
          "city": this.form.value.city,
          "state": this.form.value.state,
          "country": this.form.value.country,
          "pincode": this.form.value.pcode
      },
      "balance": this.form.value.blc,
      "availableProduct": [],
      "soldProductDetails": [],
      "availableProductSerialNo": []
    }
    this.detailsService.addManufacturer(this.data).subscribe(response=>{
      this.ngOnInit();
    })
    this.form.reset()
  }
  showCard(index)
  {
    this.cardData=!this.cardData;
    this.index=index;
  }
  
  openAdd(addContent,email){
    this.modalRef=this.modalService.open(addContent);
    this.manufacturer=email
  }
  createProduct()
  {
    this.loader=true;
    // var val = Math.floor(1000 + Math.random() * 9000);
    // console.log(val);
    // var val=this.uuid.substring(0,4);
    this.createData={
      "$class": "com.miraclesoft.blockchain.createProduct",
        "product": {
          "$class": "com.miraclesoft.blockchain.Product",
          "productQualities": {
            "$class": "com.miraclesoft.blockchain.ProductQualities",
            "productType": this.createForm.value.ptype,
            "productModel": this.createForm.value.pmodel
          },
          "productId": this.uuid,
          "productOwner":this.manufacturer,
          "warrantyPeriod": this.createForm.value.warranty,
          "availableQuantity": this.createForm.value.quantity,
          "productManufacturer": this.manufacturer,
          "productStatus": "MANUFACTURED",
          "productPrice": 0,
          "productSerialNo": [],
          "soldProductDetails": [],
          "timestamp":this.displayDate
          
        }
    }
    // console.log('--->data',this.createData);
    this.detailsService.createProduct(this.createData).subscribe(response=>{
    // console.log(response)
    if(response){
      this.modalRef.close();
      this.snackBar.open('Product Created successfully','', {
        duration: 3000,
        verticalPosition: 'top',
        horizontalPosition: 'center',
        panelClass: ['blue-snackbar']
      });
    } 
    this.createForm.reset();
    },error =>{
      this.loader=false;
      this.modalRef.close();
      let msg=JSON.parse(error._body).error.message;
        if(msg.indexOf('already') >-1){
          this.error='Product ID already exists';
          this.snackBar.open(this.error,'', {
            duration: 3000,
            verticalPosition: 'top',
            horizontalPosition: 'center',
            panelClass: ['blue-snackbar']
          });
        }
      });
  }
  openAvail(availContent,email)
  {
    this.modalRef=this.modalService.open(availContent,{ size: 'lg' });
    this.manufacturer=email
    this.detailsService.getProduct().subscribe(response=>{
      this.availData=response;
      // console.log(this.availData);
      this.displayData=[];
      for(let i=0;i<this.availData.length;i++){
        //console.log(this.availData[i].productManufacturer,'---data',this.manufacturer);
        
        if(this.availData[i].productManufacturer==this.manufacturer){
          this.displayData.push(this.availData[i]);
          // console.log(this.displayData);
        }
      }
    })
  }
  
  openSold(soldContent,email)
  {
    this.modalRef=this.modalService.open(soldContent,{ size: 'lg' });
    this.manufacturer=email
    this.detailsService.getProduct().subscribe(response=>{
      this.availData=response;
      // console.log(this.availData);
      this.displayData=[];
      this.tableData=[]
      for(let i=0;i<this.availData.length;i++){
        if(this.availData[i].productManufacturer==this.manufacturer){
          // console.log(this.availData[i]);
          if(this.availData[i].soldProductDetails!=0){
            // console.log('inside if',this.availData[i].soldProductDetails);
            this.soldData[i]=this.availData[i].soldProductDetails
            for(let j=0; j< this.soldData[i].length;j++){
              console.log(JSON.parse(this.soldData[i][j]));
              this.tableData.push(JSON.parse(this.soldData[i][j]));
            }
          }
          // else{
          //   // console.log('inside esle',this.availData[i].soldProductDetails);
          //   this.soldData[i]=this.availData[i].soldProductDetails
          //   for(let j=0; j< this.soldData[i].length;j++){
          //     console.log(JSON.parse(this.soldData[i][j]));
          //     this.tableData.push(JSON.parse(this.soldData[i][j]));
          //   }
          // }
        }
      }
    })
  }
}
