import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MandetailsComponent } from './mandetails.component';

describe('MandetailsComponent', () => {
  let component: MandetailsComponent;
  let fixture: ComponentFixture<MandetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MandetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MandetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
