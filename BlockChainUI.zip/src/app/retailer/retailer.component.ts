import { Component, OnInit } from '@angular/core';
import { SidemenuRoutesService } from '../sidemenu-routes.service';

@Component({
  selector: 'app-retailer',
  templateUrl: './retailer.component.html',
  styleUrls: ['./retailer.component.css']
})
export class RetailerComponent implements OnInit {

  constructor(public sidemenu:SidemenuRoutesService) { 
    var routes = [{
      'name':'Retailers','route':'/dashboard/retailer/retailersDetails'
    },
    // {
    //   'name':'Retailer Inventory ','route':'/dashboard/retailer/retailerdata'
    // },
    // // {
    // //   'name':'View Available Products','route':'/dashboard/retailer/availProducts'
    // // },
    // {
    //   'name':'View Sold Products','route':'/dashboard/retailer/soldProducts'
    // },
    {
      'name':'Order Product','route':'/dashboard/retailer/createProduct'
    },
    {
      'name':'Order History','route':'/dashboard/retailer/orderHistory'
    }]
    this.sidemenu.sideRoutes(routes);
  
  }

  ngOnInit() {
  }

}
