import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-retailersold',
  templateUrl: './retailersold.component.html',
  styleUrls: ['./retailersold.component.css']
})
export class RetailersoldComponent implements OnInit {
  displayData:any=[];
  responseData:any=[];
  soldData:any=[];
  constructor(private dataService:AppService) { }

  ngOnInit() {
    // this.dataService.getRetailerOrder().subscribe(response=>{
    //   this.responseData=response;
      
    //   for(let i=0;i<this.responseData.length;i++)
    //   {
    //     if(this.responseData[i].ordererType=='RETAILER')
    //     {
    //     this.displayData.push(this.responseData[i]);
    //     }
    //     if(this.responseData[i].ordererType=='CUSTOMER')
    //     {
    //       // console.log(this.responseData[i].orderQuantity);
    //       this.soldData.push(this.responseData[i].orderQuantity)
    //     }
    //   }
    // })
     this.dataService.getRetailer().subscribe(response=>{
      this.responseData=response;
      
      // for(let i=0;i<this.responseData.length;i++)
      // {
      //   if(this.responseData[i].ordererType=='RETAILER')
      //   {
      //   this.displayData.push(this.responseData[i]);
      //   }
      //   if(this.responseData[i].ordererType=='CUSTOMER')
      //   {
      //     // console.log(this.responseData[i].orderQuantity);
      //     this.soldData.push(this.responseData[i].orderQuantity)
      //   }
      // }
            for(let  i=0;i<this.responseData.length;i++){
        if(this.responseData[i].soldProductDetails.length==0){
        // console.log(i)
         this.soldData[i]={}; 
        }
        else{
          // console.log(i)
          //  this.soldData[i]=this.responseData[i].soldProductDetails[i];
         //  console.log('11111111111',this.responseData[i].soldProductDetails);
           for(let j=0; j<this.responseData[i].soldProductDetails.length;j++)
           {
            // console.log("j---", JSON.parse(this.responseData[i].soldProductDetails[j]));
            this.soldData[i]=JSON.parse(this.responseData[i].soldProductDetails[j]);
  // console.log(this.soldData[i]);
           }
           
        }
       }
    })

  }
}
