import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailersoldComponent } from './retailersold.component';

describe('RetailersoldComponent', () => {
  let component: RetailersoldComponent;
  let fixture: ComponentFixture<RetailersoldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailersoldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailersoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
