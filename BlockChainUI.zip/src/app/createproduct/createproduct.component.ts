import { Component, OnInit,ViewEncapsulation,Inject } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {Subject} from 'rxjs';
import {Location} from '@angular/common';
import {debounceTime} from 'rxjs/operators';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-createproduct',
  templateUrl: './createproduct.component.html',
  styleUrls: ['./createproduct.component.css'],
  encapsulation: ViewEncapsulation.None
})


export class CreateproductComponent implements OnInit {
 displayDate=new Date();
 createForm:FormGroup;
 loader:boolean=false
  data:any={};
 doneData:any={};
 error:any;
  constructor(  private formbuilder:FormBuilder, 
                private productService:AppService,
                private dialog: MatDialog,
                private _location:Location) {
    this.createForm=this.formbuilder.group({
      ptype:['',Validators.required],
      pmodel:['',Validators.required],
      pid:['',Validators.required],
      // man:['',[Validators.required,Validators.email]],
      warranty:['',[Validators.required,Validators.pattern('^[0-9]$')]],
      quantity:['',[Validators.required,Validators.pattern('^[0-9]+$')]]
    })
  }

  ngOnInit() { 
  }

  createProduct()
  {
    this.loader=true;
    this.data={
      "$class": "com.miraclesoft.blockchain.createProduct",
        "product": {
          "$class": "com.miraclesoft.blockchain.Product",
          "productQualities": {
            "$class": "com.miraclesoft.blockchain.ProductQualities",
            "productType": this.createForm.value.ptype,
            "productModel": this.createForm.value.pmodel
          },
          "productId": this.createForm.value.pid,
          "productOwner":"HP@gmail.com",
          "warrantyPeriod": this.createForm.value.warranty,
          "availableQuantity": this.createForm.value.quantity,
          "productManufacturer": "HP@gmail.com",
          "productStatus": "MANUFACTURED",
          "productPrice": 0,
          "productSerialNo": [],
          "soldProductDetails": [],
          "timestamp":this.displayDate
          
        }
    }
    // console.log('--->data',this.data);
    this.productService.createProduct(this.data).subscribe(response=>{
    this.doneData=response;
    this.loader=false;
      let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
        width: 'sm',
        data: {'modalDate':this.doneData.product.timestamp,'TransactionId':this.doneData.transactionId,'message':'Product Created Successfully '}
      });
  
      dialogRef.afterClosed().subscribe(result => {
        // console.log('The dialog was closed');
      });
    this.createForm.reset();
    },error =>{
      this.loader=false;
        // console.log('error',JSON.parse(error._body));
        let msg=JSON.parse(error._body).error.message;
        if(msg.indexOf('already') >-1){
          this.error='Product ID already exists';
          let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
            width: 'sm',
            data: {'message':this.error}
          });
      
          dialogRef.afterClosed().subscribe(result => {
            // console.log('The dialog was closed');
          });
        }
      });
  }
  Cancel(){
    this._location.back();
  }

}


@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'dialog-overview-example-dialog.html',
})
export class DialogOverviewExampleDialog {
  
  constructor(
    private dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 

     
    }


  close()
  {
    this.dialogRef.close();
  }

}
