import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class LoginService {
  result;
  constructor(private _http:Http) { 
  }
  
  validateLogin(formData){
    console.log("form",formData);
    return this._http.post('http://localhost:3000/login',formData)
    .map(result => 
          this.result = result.json());
          // console.log("result",result))
  }
}
