import { LoginService } from './login.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {MatSnackBar,MatSnackBarConfig} from '@angular/material';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[LoginService]
})
export class LoginComponent implements OnInit {
  form:FormGroup;
  list: Array<any>;
  username: String;
  password: String;
  error: String;
  constructor(private _logindetails: LoginService, 
              private _router:Router,
              private formbuilder:FormBuilder,
              public snackBar: MatSnackBar){
    this.form=this.formbuilder.group({
      uname:['',[Validators.required,Validators.pattern('[a-zA-Z][a-zA-Z ]*')]],
      pwd:['',[Validators.required,Validators.minLength(4),Validators.maxLength(15)]]
  })
  }
  localValue : any={};
  value:any={};
  ngOnInit() {
    this.localValue =JSON.parse(localStorage.getItem('user'));
    if(this.localValue)
    {
      if(this.localValue.length!=0){
        if(this.localValue.username=="manufacturer"){
          this._router.navigateByUrl('dashboard/manufacturer/details');
        }
        else if(this.localValue.username=="customer"){
          this._router.navigateByUrl('dashboard/customer/customerDetails');
        }
        else if(this.localValue.username=="retailer"){
          this._router.navigateByUrl('dashboard/retailer/retailersDetails');
        }
        else{
          this._router.navigateByUrl('/login');
        }
      }
    }
  }
  validateLogin(){

      this._logindetails.validateLogin(this.form.value).subscribe(response =>{
        if(response.length!=0)
        {
          if(response[0].username=="manufacturer")
          {
            this._router.navigateByUrl('dashboard/manufacturer/details');
            this.value={
              'username':response[0].username
            }
            // console.log('--->',this.value);
            localStorage.setItem('user',JSON.stringify(this.value));
          }
          else if(response[0].username=="customer")
          {
            this._router.navigateByUrl('dashboard/customer/customerDetails');
            this.value={
              'username':response[0].username
            }
            // console.log('--->',this.value);
            localStorage.setItem('user',JSON.stringify(this.value));
          }
          else if(response[0].username=="retailer")
          {
            this._router.navigateByUrl('dashboard/retailer/retailersDetails');
            this.value={
              'username':response[0].username
            }
            // console.log('--->',this.value);
            localStorage.setItem('user',JSON.stringify(this.value));
          }
        }
        else{
          console.log('inside else');
          // alert('no user in the database');
  //         let config = new MatSnackBarConfig();
  // config.panelClass = ['custom-class'];

            this.snackBar.open('Credentials not found in the database','', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
              panelClass: ['blue-snackbar']
            });
        }
         
        });
  }
}