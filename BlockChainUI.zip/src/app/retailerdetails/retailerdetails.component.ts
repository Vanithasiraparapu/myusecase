import { AvailProductsComponent } from './../avail-products/avail-products.component';
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { AppService } from '../services/app.service';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {NgbModal, ModalDismissReasons, NgbActiveModal,NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-retailerdetails',
  templateUrl: './retailerdetails.component.html',
  styleUrls: ['./retailerdetails.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class RetailerdetailsComponent implements OnInit {
  retailerData:any=[];
  closeResult: string;
  data:any={}
private modalRef: NgbModalRef;
form:FormGroup;
cardData:boolean=false;
index:any;
retailer:any;
responseData:any=[];
availData:any=[];
heighest:any;
currentAvailData:any=[];
soldData:any=[];
  constructor(private detailsService:AppService,
              private modalService: NgbModal,
              private _formbuilder:FormBuilder) {
    this.form=this._formbuilder.group({
      rid:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
      rname:['',Validators.required],
      remail:['',[Validators.required,Validators.email]],
      city:['',Validators.required],
      state:['',Validators.required],
      country:['',Validators.required],
      pcode:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
      blc:['',[Validators.required,Validators.pattern('^[0-9]+$')]]
    })
   }

  ngOnInit() {
    this.detailsService.getRetailer().subscribe(response=>{
      this.retailerData=response;
      // console.log(this.retailerData);
  })
  }
  showCard(index)
  {
    // console.log('clicked');
    this.cardData=!this.cardData;
    this.index=index;
  }
  open(content) {
    this.modalRef= this.modalService.open(content,{ size: 'lg' });
  }
  addNewRetailer(){
    console.log('-------------------',this.form.value)
    this.modalRef.close();
    this.data= {
      "$class": "com.miraclesoft.blockchain.Retailer",
      "retailerid": this.form.value.rid,
      "name": this.form.value.rname,
      "email": this.form.value.remail,
      "address": {
          "$class": "com.miraclesoft.blockchain.Address",
          "city":this.form.value.city,
          "state": this.form.value.state,
          "country": this.form.value.country,
          "pincode": this.form.value.pcode
      },
      "balance": this.form.value.blc,
      "availableProduct": [],
      "soldProductDetails": [],
      "availableProductSerialNo": []
  }
    this.detailsService.addRetailer(this.data).subscribe(response=>{
      this.ngOnInit();
    })
    this.form.reset()
  }
  openInventory(invContent,email)
  {
    this.modalRef=this.modalService.open(invContent,{ size: 'lg' });
    this.retailer=email;
      // console.log('retailer',this.retailerData,this.retailer);
      this.availData=[];
      this.currentAvailData=[];
      for(let  i=0;i<this.retailerData.length;i++){
        // console.log( this.retailer,);
        if(this.retailerData[i].email==this.retailer){
          // console.log(this.retailerData[i]);
          if(this.retailerData[i].availableProduct.length!=0){
            for(let j=0; j<this.retailerData[i].availableProduct.length;j++)
              {
              this.availData.push(JSON.parse(this.retailerData[i].availableProduct[j]));
              }
           }
          }
       }
     
  }
  openAvail(availContent,email)
  {
    console.log('inside');
    this.modalRef=this.modalService.open(availContent,{ size: 'lg' });
    this.retailer=email;
    this.availData=[];
    this.currentAvailData=[];
    for(let  i=0;i<this.retailerData.length;i++){
      // console.log( this.retailer,);
      if(this.retailerData[i].email==this.retailer){
        console.log(this.retailerData[i]);
        if(this.retailerData[i].availableProduct.length!=0){
          for(let j=0; j<this.retailerData[i].availableProduct.length;j++)
            {
            this.availData.push(JSON.parse(this.retailerData[i].availableProduct[j]));
           console.log(this.availData);

            }
         }
         if(this.retailerData[i].availableProductSerialNo.length!=0){
           for(let j=0;j<this.retailerData[i].availableProductSerialNo.length;j++){
            // console.log(JSON.parse(this.retailerData[i].availableProductSerialNo[j]));
            this.currentAvailData.push(JSON.parse(this.retailerData[i].availableProductSerialNo[j]))
            console.log(this.currentAvailData);
           }
         }
        }
     }
     if(this.availData.length>=this.currentAvailData.length){
       console.log(this.availData.length);
       this.heighest=this.availData.length;
       
     }
     else{
      console.log(this.currentAvailData.length);
      this.heighest=this.currentAvailData.length;
     }
  }

  openSold(soldContent,email)
  {
    this.modalRef=this.modalService.open(soldContent,{ size: 'lg' });
    this.retailer=email;
    this.detailsService.getRetailer().subscribe(response=>{
      this.responseData=response;
      this.soldData=[];
      console.log('retailer',this.responseData,this.retailer);
      for(let  i=0;i<this.responseData.length;i++){
        if(this.responseData[i].email==this.retailer){
          console.log(this.responseData[i].email);
          if(this.responseData[i].soldProductDetails.length==0){
            this.soldData=[];
            console.log('inside if')
           }
           else{
             console.log('inside else');
              for(let j=0; j<this.responseData[i].soldProductDetails.length;j++)
              {
               console.log(JSON.parse(this.responseData[i].soldProductDetails[j]))
              this.soldData.push(JSON.parse(this.responseData[i].soldProductDetails[j]));
              }
              
           }
          }
       }
    })
  }
   
}


