
import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
displayData:any=[];
soldData:any=[];
productSNo = {};
data:any=[]
  
constructor(private dataService:AppService) {
    
   }

  ngOnInit() {
    this.dataService.getProduct().subscribe(response=>{
      this.displayData=response;
      for(let  i=0;i<this.displayData.length;i++){
       if(this.displayData[i].soldProductDetails.length==0){

        this.data[i]={}; 
       }
       else{
          this.soldData[i]=this.displayData[i].soldProductDetails;
         // console.log('11111111111',this.soldData[i]);
          for(let j=0; j< this.soldData[i].length;j++){
            // console.log(JSON.parse(this.soldData[i][j]));
            this.data.push(JSON.parse(this.soldData[i][j]));
          }
       }
      }
    })
  }

}
