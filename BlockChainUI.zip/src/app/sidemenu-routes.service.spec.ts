import { TestBed, inject } from '@angular/core/testing';

import { SidemenuRoutesService } from './sidemenu-routes.service';

describe('SidemenuRoutesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SidemenuRoutesService]
    });
  });

  it('should be created', inject([SidemenuRoutesService], (service: SidemenuRoutesService) => {
    expect(service).toBeTruthy();
  }));
});
