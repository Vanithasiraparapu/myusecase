import { Subject } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { SidemenuRoutesService } from '../sidemenu-routes.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
   routes:any [] = [];
  constructor(public sidemenu:SidemenuRoutesService) { 
    this.sidemenu.sidemenuRoutes.subscribe(res => 
    {
      this.routes = res;
      // console.log(res,'dfghj');
    })
  }

  ngOnInit() {
  }

}
