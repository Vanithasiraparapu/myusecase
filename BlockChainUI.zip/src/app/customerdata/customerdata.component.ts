import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-customerdata',
  templateUrl: './customerdata.component.html',
  styleUrls: ['./customerdata.component.css']
})
export class CustomerdataComponent implements OnInit {
  displayData:any=[];
  responseData:any=[];
  constructor(private dataService:AppService) { }

  ngOnInit() {

    this.dataService.getOrderHistory().subscribe(response=>{
      this.responseData=response;
      
      for(let i=0;i<this.responseData.length;i++)
      {
        if(this.responseData[i].ordererType=='CUSTOMER')
        {
        this.displayData.push(this.responseData[i]);
        // console.log(this.displayData);
        }
      }
    })
  }

}
