import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailProductsComponent } from './avail-products.component';

describe('AvailProductsComponent', () => {
  let component: AvailProductsComponent;
  let fixture: ComponentFixture<AvailProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvailProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvailProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
