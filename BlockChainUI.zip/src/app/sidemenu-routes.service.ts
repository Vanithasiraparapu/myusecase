import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SidemenuRoutesService {
  public sidemenuRoutes : any = new Subject();

  sideRoutes(routes)
  {
    this.sidemenuRoutes.next(routes)
  }
  constructor() { }
}
