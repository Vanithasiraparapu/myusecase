

import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MaterialComponentsModule} from './material-components.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import { CustomerComponent } from './customer/customer.component';
import { ManufacturerComponent } from './manufacturer/manufacturer.component';
import { CreateproductComponent, DialogOverviewExampleDialog } from './createproduct/createproduct.component';
import { DataComponent } from './data/data.component';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { RetailerComponent } from './retailer/retailer.component';
import { MandetailsComponent} from './mandetails/mandetails.component';
import { AvailProductsComponent } from './avail-products/avail-products.component';
import { SoldProductsComponent } from './sold-products/sold-products.component';
import { RetailerdetailsComponent } from './retailerdetails/retailerdetails.component';
import { RetailerdataComponent } from './retailerdata/retailerdata.component';
import { RetaileravailComponent } from './retaileravail/retaileravail.component';
import { RetailersoldComponent } from './retailersold/retailersold.component';
import { CustomerdetailsComponent } from './customerdetails/customerdetails.component';
import { CustomerdataComponent } from './customerdata/customerdata.component';
import { RetailerProductComponent, DialogOverviewExample } from './retailer-product/retailer-product.component';
import { CustomerProductComponent,DialogExample } from './customer-product/customer-product.component';
import { COrderDetailsComponent } from './c-order-details/c-order-details.component';
import { ROrderDetailsComponent } from './r-order-details/r-order-details.component';

@NgModule({
  declarations: [
    // NumberPickerComponent,
    AppComponent,
    DashboardComponent,
    SidebarComponent,
    NavbarComponent,
    FooterComponent,
    LoginComponent,
    CustomerComponent,
    ManufacturerComponent,
    CreateproductComponent,
    DialogOverviewExampleDialog,
    DialogOverviewExample,
    DialogExample,
    DataComponent,
    RetailerComponent,
    MandetailsComponent,
    AvailProductsComponent,
    SoldProductsComponent,
    RetailerdetailsComponent,
    RetailerdataComponent,
    RetaileravailComponent,
    RetailersoldComponent,
    CustomerdetailsComponent,
    CustomerdataComponent,
    RetailerProductComponent,
    CustomerProductComponent,
    COrderDetailsComponent,
    ROrderDetailsComponent  
  ],
  schemas:[NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    BrowserAnimationsModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    NgbModule.forRoot(),
    MaterialComponentsModule,
    FlexLayoutModule,
    Ng4LoadingSpinnerModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents:[ DialogOverviewExampleDialog,DialogOverviewExample]
})
export class AppModule { }
