import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerdataComponent } from './retailerdata.component';

describe('RetailerdataComponent', () => {
  let component: RetailerdataComponent;
  let fixture: ComponentFixture<RetailerdataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailerdataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailerdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
