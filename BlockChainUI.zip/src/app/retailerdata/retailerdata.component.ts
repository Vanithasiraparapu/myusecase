import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';
@Component({
  selector: 'app-retailerdata',
  templateUrl: './retailerdata.component.html',
  styleUrls: ['./retailerdata.component.css']
})
export class RetailerdataComponent implements OnInit {
  displayData:any=[];
  responseData:any=[];
  soldData:any=[];
  availQty:any=[];
  constructor(private dataService:AppService) { }

  ngOnInit() {
    this.dataService.getRetailer().subscribe(response=>{
      this.responseData=response;
      // console.log(this.responseData);
      for(let  i=0;i<this.responseData.length;i++){
        // if(this.responseData[i].availableProduct.length==0){
        //  this.availQty.push({}); 
        // }
        // else{
           for(let j=0; j<this.responseData[i].availableProduct.length;j++)
           {
            //  console.log(JSON.parse(this.responseData[i].availableProduct[j]));
            this.availQty.push(JSON.parse(this.responseData[i].availableProduct[j]));
            console.log(this.availQty);
           }
           
        // }
       }
    })
  }
  }
