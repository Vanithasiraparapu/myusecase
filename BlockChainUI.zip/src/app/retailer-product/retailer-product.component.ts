import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { AppService } from '../services/app.service';
import {NgbModal, ModalDismissReasons, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import {Subject} from 'rxjs';
import {debounceTime} from 'rxjs/operators';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { UUID } from 'angular2-uuid';
@Component({
  selector: 'app-retailer-product',
  templateUrl: './retailer-product.component.html',
  styleUrls: ['./retailer-product.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class RetailerProductComponent implements OnInit {
  displayDate=new Date();
  uuid = UUID.UUID();
  error:any
  data:any=[];
  soldData:any=[];
  form:FormGroup;
  orderData:any={};
  displayData:any=[];
  doneData:any=[];
  manufacturers:any=[];
  retailers:any=[];
  productTypes:any=[];
  productModels:any=[];
  private modalRef: NgbModalRef;
  constructor(private placeOrderService:AppService,
              private modalService: NgbModal,
              private _formbuilder:FormBuilder, 
              private dialog: MatDialog) {
    this.form=this._formbuilder.group({
      // rid:['',[Validators.required,Validators.pattern('^[0-9]+$')]],
      rname:[''],
      type:['',Validators.required],
      model:['',Validators.required],
      owner:[''],
      qty:['',Validators.required]
    })
   }

    ngOnInit() {
      // console.log('----------',this.uuid);
      this.placeOrderService.getProduct().subscribe(response=>{
        this.data=response;
        // console.log(this.data);
    })
    this.placeOrderService.getManufacturer().subscribe(res=>{
      // console.log(res.email);
      for(let i=0;i<res.length;i++){
        this.manufacturers.push(res[i].email);
        // console.log(this.manufacturers);
      }
    })
    this.placeOrderService.getRetailer().subscribe(response=>{
      // console.log(response);
      for(let i=0;i<response.length;i++){
        this.retailers.push(response[i].email);
      }
  })
  }

  onManufacturerSelect(value){
    // console.log(value.substring(3));
    // console.log(this.data[0].productManufacturer);
    this.productTypes=[];
    for(let i=0;i<this.data.length;i++){
      if(this.data[i].productManufacturer==value.substring(3)){
        // console.log('inside if');
        // console.log(this.data[i].productQualities.productType);
        this.productTypes.push(this.data[i].productQualities.productType)
        // console.log(this.productTypes);
      }
    }
    
  }
  onRetailerSelect(value)
  {

  }
  
  onTypeSelect(value){
    console.log(value);
    this.productModels=[];
    for(let i=0;i<this.data.length;i++){
      if(this.data[i].productQualities.productType==value.substring(3)){
      // console.log(this.data[i].productQualities.productModel);
      this.productModels.push(this.data[i].productQualities.productModel);
      }
    }
  }
  onModelSelect(value){

  }
  open(content){
    this.modalRef= this.modalService.open(content, { size: 'lg' });
  }
  addNewOrder()
  {
    // this.modalRef.close();
    // var val = Math.floor(1000 + Math.random() * 9000);
    // console.log(val);
    // var val=this.uuid.substring(0,4);
    this.orderData={
        "$class": "com.miraclesoft.blockchain.orderProduct",
        "order": {
          "$class": "com.miraclesoft.blockchain.Order",
          "orderId": this.uuid,
          "orderDate": this.displayDate,
          "orderPerson": this.form.value.rname,
          "ordererType": "RETAILER",
          "orderStatus": "CREATED",
          "orderProviderName": this.form.value.owner,
          "productQualities": {
            "$class": "com.miraclesoft.blockchain.ProductQualities",
            "productType": this.form.value.type,
            "productModel": this.form.value.model,
            "productConfiguration": "string"
          },
          "orderQuantity": this.form.value.qty,
          "saleItemSerial": []
        },
        "timestamp": this.displayDate
      }
      // console.log('---------',this.orderData);
      this.placeOrderService.placeRetailerOrder(this.orderData).subscribe(response=>{
        this.doneData=response;
        // console.log(response);
        let dialogRef = this.dialog.open(DialogOverviewExample, {
          width: 'sm',
          data: {'modalDate':this.doneData.order.orderDate,'TransactionId':this.doneData.transactionId,'message':'Order Created Successfully '}
        });
    
        dialogRef.afterClosed().subscribe(result => {
          // console.log('The dialog was closed');
        });
        this.form.reset();
        this.ngOnInit();
      },error=>{
        let msg=JSON.parse(error._body).error;
        if(msg){
          this.error='Error in placing the order';
          let dialogRef = this.dialog.open(DialogOverviewExample, {
            width: 'sm',
            data: {'message':this.error}
          });
      
          dialogRef.afterClosed().subscribe(result => {
            // console.log('The dialog was closed');
          });
        }
        this.form.reset();
        this.ngOnInit();
      })
      
  }
}



@Component({
  selector: 'dialog-overview-example',
  templateUrl: 'dialog-overview-example.html',
})
export class DialogOverviewExample {
  
  constructor(
    private dialogRef: MatDialogRef<DialogOverviewExample>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 

     
    }


  close()
  {
    this.dialogRef.close();
  }

}