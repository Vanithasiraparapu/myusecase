import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ROrderDetailsComponent } from './r-order-details.component';

describe('ROrderDetailsComponent', () => {
  let component: ROrderDetailsComponent;
  let fixture: ComponentFixture<ROrderDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ROrderDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ROrderDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
