import { Component, OnInit, ChangeDetectorRef, HostListener } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  footerTop:any='';
  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
       constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,private _router:Router) {
         this.mobileQuery = media.matchMedia('(max-width: 959px)');
         this._mobileQueryListener = () => changeDetectorRef.detectChanges();
         this.mobileQuery.addListener(this._mobileQueryListener);
       }

   localValue:any={};  
  ngOnInit() { 
    this.localValue =JSON.parse(localStorage.getItem('user'));
    // console.log('onInit',this.localValue.username);
      if(this.localValue.username=="manufacturer"){
        this._router.navigateByUrl('dashboard/manufacturer/details');
      }
      else if(this.localValue.username=="customer"){
        this._router.navigateByUrl('dashboard/customer/customerDetails');
      }
      else if(this.localValue.username=="retailer"){
        this._router.navigateByUrl('dashboard/retailer/retailersDetails');
      }
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

}
